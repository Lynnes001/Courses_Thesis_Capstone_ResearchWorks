# Webapplication-project

### Phase 1 - Data Collection Module
Code & Programs (with Readme files)

### Documents
Diagrams, Reports, UML, database schema
