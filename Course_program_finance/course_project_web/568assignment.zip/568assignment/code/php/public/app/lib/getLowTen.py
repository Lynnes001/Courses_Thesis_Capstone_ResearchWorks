#!/usr/bin/env python

# written by: Zhuohang Li
from alpha_vantage.timeseries import TimeSeries
import numpy as np
import sys

def get_low(symbol, period='10days'):
    ts = TimeSeries(key='0345Y49CIQ03XJK3', output_format='pandas')
    data, meta_data = ts.get_daily(symbol=symbol, outputsize='full')
    if(period=='10days'):
        slice=data.tail(10)
    if(period=='1year'):
        slice=data.tail(365)
    sorted=slice.sort_values(by='3. low')
    a=list(sorted.head(1).index)
    b=np.array(sorted.head(1)).tolist()
    c=[b[0][0],b[0][1],b[0][2],b[0][3],b[0][4]]
    a.extend(c)
    return a

res = get_low(sys.argv[1])
print(res[0])
print(res[1])
print(res[2])
print(res[3])
print(res[4])
print(res[5])

