import pandas as pd
import sys

# written by: Yiyuan Fu
#def gethistorydata():
 #  ts = TimeSeries(key='FXWWAQNNY39WXKVY', output_format='pandas')
  # data= ts.get_daily(symbol=companyname,outputsize='full')
   #realdata=data[0]
   #realdata.to_csv(companyname+'_history.csv',index=True,sep=',')  


def getdate():    
    data=pd.read_csv(companyname+'_history.csv')   
    date=data['date']                 
    datedata=[]                           
    for i in date:
        datedata.append(i)    
    return datedata

def getclosedata():    
    data=pd.read_csv(companyname+'_history.csv')   
    close=data['4. close']                 
    closedata=[]                           
    for i in close:
        closedata.append(i)    
    return closedata
	
def getvolume():
    data=pd.read_csv(companyname+'_history.csv')
    volume=data['5. volume']                 
    volumedata=[]                           
    for i in volume:
        volumedata.append(i)    
    return volumedata

def getopendata():   
    data=pd.read_csv(companyname+'_history.csv')    
    open=data['1. open']
    opendata=[]
    for i in open:
        opendata.append(i)    
    return opendata

def getvolumeRadio():
    ope=getopendata()
    close=getclosedata()
    volume=getvolume()
    a=0
    d=0
    u=0
    for i in range(0,len(ope)-1):
        if close[i]>ope[i]:
            a=a+volume[i]
        elif close[i]<ope[i]:
            d=d+volume[i]
        else:
            u=u+volume[i]
    vr=(a+u/2)/(d+u/2)
    return vr
    # if vr<0.7 and vr>0.4:
       # print(" suggestion : buy")
    # elif vr>=0.7 and vr<1.6:
        # print(" suggestion : hold")
    # elif vr>=1.6:
        # print(" suggestion : sell")
    # else:
        # print("unable to give suggestion")

companyname = sys.argv[1]

vr = getvolumeRadio()
print companyname + '11'
print 'vr'

print vr











