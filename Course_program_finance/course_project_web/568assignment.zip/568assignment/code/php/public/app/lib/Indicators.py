from alpha_vantage.techindicators import TechIndicators
from alpha_vantage.timeseries import TimeSeries
import matplotlib.pyplot as plt
import sys

# written by: Zhuohang Li
def get_historical_data(stockSymbol):
    ts = TimeSeries(key='0345Y49CIQ03XJK3', output_format='pandas')
    data, meta_data = ts.get_daily(symbol=stockSymbol, outputsize='full')
    # data.to_csv("/data/"+stockSymbol + '_history.csv', index=True, sep=',')
    return data

def get_macd(stockSymbol):
    ti = TechIndicators(key='0345Y49CIQ03XJK3', output_format='pandas')
    data, meta_data = ti.get_macd(symbol=stockSymbol, interval='daily', series_type='close')
    # data.to_csv("/data/"+stockSymbol + '_macd.csv', index=True, sep=',')

    return data.MACD_Hist


def get_stoch(stockSymbol):
    ti = TechIndicators(key='D7S3A5PAJKXHW45Q', output_format='pandas')
    data, meta_data = ti.get_stoch(symbol=stockSymbol, interval='daily')
    data.reindex(columns=["date", "SlowK", "SlowD"])
    # data.to_csv(stockSymbol + '_stoch.csv', index=True, sep=',')

    SlowK = data.SlowK
    SlowD = data.SlowD
    #date = data.date
    return SlowK, SlowD

def get_obv(stockSymbol):
    ti = TechIndicators(key='0345Y49CIQ03XJK3', output_format='pandas')
    data, meta_data = ti.get_obv(symbol=stockSymbol, interval='daily')
    data.to_csv(stockSymbol + '_obv.csv', index=True, sep=',')

def get_ema(stockSymbol):
    ti = TechIndicators(key='0345Y49CIQ03XJK3', output_format='pandas')
    data, meta_data = ti.get_ema(symbol=stockSymbol, interval='daily', series_type='close')
    data.to_csv(stockSymbol + '_ema.csv', index=True, sep=',')

def get_rsi(stockSymbol):
    ti = TechIndicators(key='0345Y49CIQ03XJK3', output_format='pandas')
    data, meta_data = ti.get_rsi(symbol=stockSymbol, interval='daily', series_type='close', time_period='60')
    data.to_csv(stockSymbol + '_rsi.csv', index=True, sep=',')

def get_cci(stockSymbol):
    ti = TechIndicators(key='0345Y49CIQ03XJK3', output_format='pandas')
    data, meta_data = ti.get_cci(symbol=stockSymbol, interval='daily', time_period='60')
    print(data)
    # data.to_csv(stockSymbol + '_rsi.csv', index=True, sep=',')




stockSymbol = sys.argv[1]
indicatorType = sys.argv[2]




#print(get_macd(stockSymbol))

loopNum = 500
if indicatorType == "K":
    resK, resD = get_stoch(stockSymbol)
    resK = resK.values
    for i in range(loopNum):
        print(resK[i])

if indicatorType == "D":
    resK, resD = get_stoch(stockSymbol)
    resD = resD.values
    for i in range(loopNum):
        print(resD[i])

if indicatorType == "MACD":
    resMACD = get_macd(stockSymbol).values
    for i in range(loopNum):
        print(resMACD[i])




#    get_obv(stockSymbol)
#    get_ema(stockSymbol)
#    get_rsi(stockSymbol)
