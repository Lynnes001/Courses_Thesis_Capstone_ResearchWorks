<?php
/**
 * Created by SongYang.
 * User: lynn
 * Date: 4/21/18
 * Time: 8:14 PM
 */


use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;


require 'lib/mysql.php';


$app->get('/', function ($request, $response, $args) {
    $response->write("Hello, Welcome to Slim Framework!!!");
    return $response;
});





// real-time price.

// get the realtime price of {stockid}
$app->get('/{stockid}/realtime', function($request, $response, $args) {
    $stockid = $args['stockid'];
    exec("python app/lib/getReal.py $stockid",$realtime);
    $response->getBody()->write(json_encode($realtime));
    return $response;
});

// get today's prices
// today's opening price
$app->get('/{stockid}/realtime/open', function($request, $response, $args) {
    //get_employee_id($args['id']);
});

// today's opening price
$app->get('/{stockid}/realtime/close', function($request, $response, $args) {
    //get_employee_id($args['id']);
});


// get price in 10 days.
// highest price in 10 days
$app->get('/{stockid}/10d/highest', function($request, $response, $args) {
    $stockid = $args['stockid'];
    exec("python app/lib/getHighTen.py $stockid",$high);
    $response->getBody()->write(json_encode($high));
    return $response;
});


// avg price in a year
$app->get('/{stockid}/year/avg', function($request, $response, $args) {
    $stockid = $args['stockid'];
    exec("python app/lib/getAvgYear.py $stockid",$avg);
    $response->getBody()->write(json_encode($avg));
    return $response;
});

// highest price in a year
$app->get('/{stockid}/year/high', function($request, $response, $args) {
    $stockid = $args['stockid'];
    exec("python app/lib/getHighYear.py $stockid",$avg);
    $response->getBody()->write(json_encode($avg));
    return $response;
});

// avg price in 10 days
$app->get('/{stockid}/10d/avg', function($request, $response, $args) {
    $stockid = $args['stockid'];
    exec("python app/lib/getAvgTen.py $stockid",$avg);

    $realdata["avg"] = $avg;
    $res["data"] = $realdata;
    $res["msg"] = $stockid;
    $res["code"] = 200;
    $response->write(json_encode($res));
    return $response;
});

// get history prices (in a year)
// history opening prices
$app->get('/{stockid}/history/open', function($request, $response, $args) {
    // pricetype 1. open  2. high  3. low  4. close  5: volume
    $stockid = $args['stockid'];
    $priceType = "1. open";
    $command = "python app/lib/historical_json.py $stockid \"$priceType\"";
    exec($command,$history);
    $str = '{"open":'.json_encode($history).'}';
    $response->write($str);
    return $response;
});

// history close prices (in a year)
$app->get('/{stockid}/history/close', function($request, $response, $args) {
    // pricetype 1. open  2. high  3. low  4. close  5: volume
    $stockid = $args['stockid'];
    $priceType = "4. close";
    $command = "python app/lib/historical_json.py $stockid \"$priceType\"";
    exec($command,$history);
    $str = '{"close":'.json_encode($history).'}';
    $response->write($str);
    return $response;
});

// history low prices (in a year)
$app->get('/{stockid}/history/low', function($request, $response, $args) {
    // pricetype 1. open  2. high  3. low  4. close  5: volume
    $stockid = $args['stockid'];
    $priceType = "3. low";
    $command = "python app/lib/historical_json.py $stockid \"$priceType\"";
    exec($command,$history);
    $str = '{"low":'.json_encode($history).'}';
    $response->write($str);
    return $response;
});

// history high prices (in a year)
$app->get('/{stockid}/history/high', function($request, $response, $args) {
    // pricetype 1. open  2. high  3. low  4. close  5: volume
    $stockid = $args['stockid'];
    $priceType = "2. high";
    $command = "python app/lib/historical_json.py $stockid \"$priceType\"";
    exec($command,$history);
    $str = '{"high":'.json_encode($history).'}';
    $response->write($str);
    return $response;
});

// history volume prices (in a year)
$app->get('/{stockid}/history/volume', function($request, $response, $args) {
    // pricetype 1. open  2. high  3. low  4. close  5: volume
    $stockid = $args['stockid'];
    $priceType = "5. volume";
    $command = "python app/lib/historical_json.py $stockid \"$priceType\"";
    exec($command,$history);
    $str = '{"volume":'.json_encode($history).'}';
    $response->write($str);
    return $response;
});

// get today's all prices
$app->get('/{stockid}/realtime/all', function($request, $response, $args) {
    //get_employee_id($args['id']);
});


// indicators
$app->get('/{stockid}/indicators/{type}', function($request, $response, $args) {
    // pricetype 1. open  2. high  3. low  4. close  5: volume
    $stockid = $args['stockid'];
    $type = $args['type'];
    $command = "python app/lib/Indicators.py $stockid \"$type\"";
    exec($command,$type);
    $str = '{"val":'.json_encode($type).'}';
    $response->write($str);
    return $response;
});

//get from database
$app->get('/{stockid}/indicatorsdb/{type}', function ($request, $response, $args) {
    $stockid = $args['stockid'];
    $res = get_macd($stockid);

    $outputarr = array();
    foreach ($res as $arr){
        array_push($outputarr, $arr['macd']);
    }
    $str = '{"val":'.json_encode($outputarr).'}';
    $response->write($str);

    return $response;
});


// RNN
$app->get('/{stockid}/rnn', function($request, $response, $args) {
    $stockid = $args['stockid'];
    exec("python app/lib/RNN_Xin_Yang.py $stockid",$nn);
    $response->getBody()->write(json_encode($nn));
    return $response;
});

// Bayesian
$app->get('/{stockid}/bay', function($request, $response, $args) {
    $stockid = $args['stockid'];
    exec("python app/lib/bayesian.py $stockid",$bay);
    $response->getBody()->write(json_encode($bay));
    return $response;
});


// SVM
$app->get('/{stockid}/svm', function($request, $response, $args) {
    $stockid = $args['stockid'];
    exec("python app/lib/svm.py $stockid",$realtime);
    $response->getBody()->write(json_encode($realtime));
    return $response;
});


?>
