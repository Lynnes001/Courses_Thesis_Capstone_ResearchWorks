#!/usr/bin/env python

# written by: Zhuohang Li
from alpha_vantage.timeseries import TimeSeries
import numpy as np
import sys

def get_avg_value(symbol, period='1year'):
    ts = TimeSeries(key='0345Y49CIQ03XJK3', output_format='pandas')
    data, meta_data = ts.get_daily(symbol=symbol, outputsize='full')
    if(period=='10days'):
        slice=data.tail(10)
    if(period=='1year'):
        slice=data.tail(365)
    # print(slice)
    close=slice['4. close']
    return close.mean()


res = get_avg_value(sys.argv[1])
print(res)


