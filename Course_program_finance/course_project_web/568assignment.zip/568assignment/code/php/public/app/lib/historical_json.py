#!/usr/bin/env python

from alpha_vantage.timeseries import TimeSeries
import sys, json
import time

# written by: Zhuohang Li
priceType = sys.argv[2]
stockSymbol = sys.argv[1]
ts = TimeSeries(key='0345Y49CIQ03XJK3', output_format='json')  # replace YOUR_API_KEY with your key
data, meta_data = ts.get_daily(symbol=stockSymbol, outputsize='full')

#       "5. volume": "1310200",
#		"4. close": "575.2800",
#		"2. high": "579.5700",
#		"1. open": "578.6600",
#		"3. low": "574.7500"

#print(json.dumps(data))
# stores date
res = []

# stores open price
open = []

for date in data:
    # print(date)
    # counter = 0
    # for val in data[date]:
    # print(data[date]["1. open"])
    open.append(data[date][priceType])

for i in range(500):
    print(open[i])

#print(timeStamp)
