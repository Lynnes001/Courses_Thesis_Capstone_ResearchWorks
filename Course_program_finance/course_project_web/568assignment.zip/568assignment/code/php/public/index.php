<?php
/**
 * Created by Song Yang.
 * User: lynn
 * Date: 4/21/18
 * Time: 7:55 PM
 */
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require __DIR__ . '/../vendor/autoload.php';
session_start();

$app = new \Slim\App();


// Register routes
require __DIR__ . '/app/dboper.php';



$app->run();
